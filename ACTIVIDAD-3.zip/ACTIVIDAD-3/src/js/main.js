document.getElementById("btnExplorar").onclick = () => {
  window.location.href = "catalogo.html";
};
